import gridMath
import shapefile

from tkinter import *
window = Tk()
c = Canvas(window, width = 360, height = 640, bg='black')
c.pack()

lines = []
def draw(shapeArray, colour, divider, locationData):
	shapeCount = len(shapeArray)

	for i in range(shapeCount):
		currentPoints = shapeArray[i].points
		pointCount = len(currentPoints)

		for p in range(pointCount - 1):
			x1 = currentPoints[p][0] / divider - locationData[0] / divider + 180
			y1 = currentPoints[p][1] / divider - locationData[1] / divider + 320

			x2 = currentPoints[p + 1][0] / divider - locationData[0] / divider + 180
			y2 = currentPoints[p + 1][1] / divider - locationData[1] / divider + 320

			newLine = c.create_line(x1, 640 - y1, x2, 640 - y2, fill=colour)
			lines.append(newLine)

def loadShapes(path):
	newFile = shapefile.Reader(path)
	return newFile.shapes()

import location
startLocation = gridMath.latLongToGrid(location.getLatLong())

surreyRoads = loadShapes("data/TQ_RoadLink.shp")
ukRivers = loadShapes("data/WatercourseLink.shp")

divider = 6
draw(surreyRoads, 'grey', divider, startLocation)
draw(ukRivers, 'blue', divider, startLocation)

def refresh():
	global startLocation

	currentLocation = gridMath.latLongToGrid(location.getLatLong())
	difference = [currentLocation[0] - startLocation[0], currentLocation[1] - startLocation[1]]

	for line in lines:
		c.move(line, difference[0], difference[1])

	startLocation = currentLocation
	c.after(1000, refresh) # run one after the other (recursive)
refresh()

c.mainloop()
